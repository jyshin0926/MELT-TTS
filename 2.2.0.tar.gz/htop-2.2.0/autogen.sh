#!/bin/sh
mkdir -p m4
autoreconf --install --force
